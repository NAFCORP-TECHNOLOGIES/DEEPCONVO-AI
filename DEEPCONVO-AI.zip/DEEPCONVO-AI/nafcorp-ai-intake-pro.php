<?php
/*
Plugin Name: DeepConvo AI
Plugin URI: https://nafcorp.com.au/
Description: DeepConvo AI is a smart, AI-powered assistant plugin for WordPress that helps businesses instantly collect project requirements from clients. Now powered by OpenAI Responses API.
Version: 2.0
Author: NAFCORP TECHNOLOGIES
Author URI: https://nafcorp.com.au/
License: GPL2
*/

// Prevent direct access
if (!defined('ABSPATH')) exit;

// Include API Handler for Tier System and Registration
require_once plugin_dir_path(__FILE__) . 'nafcorp-api-handler.php';

// Enqueue scripts and styles
function nafcorp_ai_intake_enqueue_scripts() {
    $settings = get_option('nafcorp_ai_intake_settings', []);
    
    wp_enqueue_style('dashicons', false, [], '2.0');
    wp_enqueue_style('nafcorp-ai-intake-styles', plugin_dir_url(__FILE__) . 'assets/styles.css', [], '2.0');
    wp_enqueue_script('nafcorp-ai-intake-chatbot', plugin_dir_url(__FILE__) . 'assets/chatbot.js', ['jquery'], '2.0', true);
    
    // Pass PHP settings to JS (Enhanced with new features)
    wp_localize_script('nafcorp-ai-intake-chatbot', 'nafcorpSettings', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('nafcorp_chat_nonce'),
        'botName'  => $settings['bot_name'] ?? 'AI Assistant',
        'starters' => $settings['starters'] ?? [],
        'primaryColor' => $settings['primary_color'] ?? '#1DFF85',
        'openingMsg' => $settings['opening_message'] ?? 'How can I help you today?',
        'position' => $settings['position'] ?? 'right',
        'model'    => $settings['model'] ?? 'gpt-4o-mini',
        'temperature' => $settings['temperature'] ?? 0.7,
        'enable_tts' => $settings['enable_tts'] ?? true,
        // Legacy support
        'voice'    => $settings['voice'] ?? 'alloy',
        'is_logged_in' => is_user_logged_in(),
        'use_realtime' => $settings['use_realtime'] ?? false
    ]);
    
    // Also keep legacy localization for backward compatibility
    wp_localize_script('nafcorp-ai-intake-chatbot', 'nafcorpAI', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('nafcorp_ai_nonce'),
        'voice'    => $settings['voice'] ?? 'alloy',
        'enable_tts' => $settings['enable_tts'] ?? true,
        'is_logged_in' => is_user_logged_in(),
        'use_realtime' => $settings['use_realtime'] ?? false,
        'realtime_token_url' => admin_url('admin-ajax.php?action=nafcorp_ai_get_realtime_token')
    ]);
}
add_action('wp_enqueue_scripts', 'nafcorp_ai_intake_enqueue_scripts');

// Shortcode to render chatbot
function nafcorp_ai_intake_shortcode() {
    return '<div id="nafcorp-ai-intake-wrapper"></div>';
}
add_shortcode('nafcorp_ai_intake', 'nafcorp_ai_intake_shortcode');

// ============================================
// OpenAI Responses API - File Upload Helper
// ============================================

/**
 * Upload knowledge file to OpenAI for use with file_search tool
 * Called when knowledge file is updated in settings
 */
function nafcorp_sync_assistant() {
    $settings = get_option('nafcorp_ai_intake_settings', []);
    $api_key = $settings['api_key'] ?? '';
    
    if (empty($api_key)) {
        return false;
    }

    // Only handle file upload if needed
    if (empty($settings['needs_openai_sync']) || empty($settings['knowledge_file_path'])) {
        return true; // Nothing to sync
    }

    // Delete old file if it exists
    if (!empty($settings['openai_file_id'])) {
        wp_remote_request('https://api.openai.com/v1/files/' . $settings['openai_file_id'], [
            'headers' => ['Authorization' => 'Bearer ' . $api_key],
            'method' => 'DELETE',
            'timeout' => 15
        ]);
    }

    // Delete old vector store if it exists
    if (!empty($settings['openai_vector_store_id'])) {
        wp_remote_request('https://api.openai.com/v1/vector_stores/' . $settings['openai_vector_store_id'], [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'OpenAI-Beta' => 'assistants=v2'
            ],
            'method' => 'DELETE',
            'timeout' => 15
        ]);
    }
    
    // Upload file to OpenAI
    $file_path = $settings['knowledge_file_path'];
    
    if (!file_exists($file_path)) {
        return false;
    }
    
    $file_content = file_get_contents($file_path);
    $filename = basename($file_path);
    $boundary = '----WebKitFormBoundary' . md5(time());
    
    $upload_headers = [
        'Authorization' => 'Bearer ' . $api_key,
        'Content-Type' => 'multipart/form-data; boundary=' . $boundary
    ];
    
    $payload_upload = '';
    $payload_upload .= "--{$boundary}\r\n";
    $payload_upload .= "Content-Disposition: form-data; name=\"purpose\"\r\n\r\n";
    $payload_upload .= "assistants\r\n";
    $payload_upload .= "--{$boundary}\r\n";
    $payload_upload .= "Content-Disposition: form-data; name=\"file\"; filename=\"" . $filename . "\"\r\n";
    $payload_upload .= "Content-Type: application/octet-stream\r\n\r\n";
    $payload_upload .= $file_content . "\r\n";
    $payload_upload .= "--{$boundary}--\r\n";

    $file_response = wp_remote_post('https://api.openai.com/v1/files', [
        'headers' => $upload_headers,
        'body' => $payload_upload,
        'timeout' => 60
    ]);
    
    if (!is_wp_error($file_response)) {
        $file_data = json_decode(wp_remote_retrieve_body($file_response), true);
        $file_id = $file_data['id'] ?? null;
        
        if ($file_id) {
            // Create Vector Store and add file
            $vs_payload = [
                'name' => 'DeepConvo Knowledge Base',
                'file_ids' => [$file_id]
            ];
            
            $vs_response = wp_remote_post('https://api.openai.com/v1/vector_stores', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $api_key,
                    'Content-Type' => 'application/json',
                    'OpenAI-Beta' => 'assistants=v2'
                ],
                'body' => wp_json_encode($vs_payload),
                'timeout' => 30
            ]);
            
            if (!is_wp_error($vs_response)) {
                $vs_data = json_decode(wp_remote_retrieve_body($vs_response), true);
                $vector_store_id = $vs_data['id'] ?? null;
                
                if ($vector_store_id) {
                    $settings['openai_file_id'] = $file_id;
                    $settings['openai_vector_store_id'] = $vector_store_id;
                    $settings['needs_openai_sync'] = false;
                    unset($settings['openai_assistant_id']); // No longer needed
                    update_option('nafcorp_ai_intake_settings', $settings);
                    return true;
                }
            }
        }
    }
    
    return false;
}

// ============================================
// OpenAI Responses API Chat Handler
// WITH TTS SUPPORT
// ============================================

add_action('wp_ajax_nafcorp_chat_message', 'nafcorp_handle_responses_message');
add_action('wp_ajax_nopriv_nafcorp_chat_message', 'nafcorp_handle_responses_message');

function nafcorp_handle_responses_message() {
    check_ajax_referer('nafcorp_chat_nonce', 'nonce');
    
    $settings = get_option('nafcorp_ai_intake_settings', []);
    $api_key = $settings['api_key'] ?? '';
    $user_message = isset($_POST['message']) ? sanitize_text_field(wp_unslash($_POST['message'])) : '';
    $voice = $settings['voice'] ?? 'alloy';
    $enable_tts = $settings['enable_tts'] ?? true;
    
    if (empty($api_key)) {
        wp_send_json_error(['error' => 'OpenAI API key not configured.']);
        return;
    }
    
    if (empty($user_message)) {
        wp_send_json_error(['error' => 'Message is required.']);
        return;
    }

    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Get previous response ID for multi-turn conversations
    $previous_response_id = $_SESSION['nafcorp_last_response_id'] ?? null;
    
    // Build tools array
    $tools = [];
    
    if (!empty($settings['enable_code_interpreter']) || !empty($settings['code_interpreter'])) {
        $tools[] = ['type' => 'code_interpreter'];
    }
    
    if (!empty($settings['enable_file_search']) && !empty($settings['openai_vector_store_id'])) {
        $tools[] = [
            'type' => 'file_search',
            'vector_store_ids' => [$settings['openai_vector_store_id']]
        ];
    }

    // Prepare input
    $input = $user_message;
    
    // Prepare request payload
    $payload = [
        'model' => $settings['model'] ?? 'gpt-4o',
        'input' => $input,
        'instructions' => $settings['system_prompt'] ?? 'You are a helpful assistant.',
        'store' => true
    ];
    
    if (!empty($tools)) {
        $payload['tools'] = $tools;
    }
    
    // Use previous_response_id for multi-turn conversations
    if ($previous_response_id) {
        $payload['previous_response_id'] = $previous_response_id;
    }
    
    // Add temperature and other settings
    if (isset($settings['temperature'])) {
        $payload['temperature'] = floatval($settings['temperature']);
    }
    
    if (isset($settings['max_tokens'])) {
        $payload['max_output_tokens'] = intval($settings['max_tokens']);
    }

    // Call Responses API
    $response = wp_remote_post('https://api.openai.com/v1/responses', [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json'
        ],
        'body' => wp_json_encode($payload),
        'timeout' => 60
    ]);

    if (is_wp_error($response)) {
        wp_send_json_error(['error' => 'API request failed: ' . $response->get_error_message()]);
        return;
    }

    $http_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $result = json_decode($body, true);
    
    // Log the raw response for debugging
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log('OpenAI Response Code: ' . $http_code);
        error_log('OpenAI Response Body: ' . $body);
        error_log('Payload sent: ' . wp_json_encode($payload));
    }
    
    // Check for API errors
    if ($http_code !== 200) {
        $error_message = 'API Error';
        if (isset($result['error']['message'])) {
            $error_message = $result['error']['message'];
        } elseif (isset($result['error'])) {
            $error_message = is_string($result['error']) ? $result['error'] : wp_json_encode($result['error']);
        }
        wp_send_json_error([
            'error' => $error_message,
            'http_code' => $http_code,
            'details' => $result
        ]);
        return;
    }
    
    if (empty($result['id'])) {
        wp_send_json_error([
            'error' => 'Invalid API response - no ID returned',
            'http_code' => $http_code,
            'details' => $result
        ]);
        return;
    }

    // Store response ID for next turn
    $_SESSION['nafcorp_last_response_id'] = $result['id'];
    
    // Extract text from output
    $assistant_message = '';
    if (isset($result['output']) && is_array($result['output'])) {
        foreach ($result['output'] as $item) {
            if ($item['type'] === 'message' && isset($item['content'])) {
                foreach ($item['content'] as $content) {
                    if ($content['type'] === 'output_text') {
                        $assistant_message .= $content['text'];
                    }
                }
            }
        }
    }
    
    // Fallback to output_text helper if available
    if (empty($assistant_message) && isset($result['output_text'])) {
        $assistant_message = $result['output_text'];
    }

    // ============================================
    // GENERATE TTS AUDIO IF ENABLED
    // ============================================
    $audio_url = '';
    if ($enable_tts && !empty($assistant_message)) {
        $tts_result = nafcorp_generate_tts($assistant_message, $voice, $api_key);
        if (is_array($tts_result) && !empty($tts_result['url'])) {
            $audio_url = $tts_result['url'];
        } elseif (is_string($tts_result)) {
            $audio_url = $tts_result;
        }
    }

    wp_send_json_success([
        'reply' => $assistant_message,
        'response_id' => $result['id'],
        'audio_url' => $audio_url
    ]);
}

// ============================================
// LEGACY: Standard Chat Completions API Handler
// Kept for backward compatibility
// ============================================

// AJAX Chat Handler (Standard Chat Completions API)
add_action('wp_ajax_nopriv_nafcorp_ai_chat', 'nafcorp_ai_chat');
add_action('wp_ajax_nafcorp_ai_chat', 'nafcorp_ai_chat');

function nafcorp_ai_chat() {
    check_ajax_referer('nafcorp_ai_nonce', 'nonce');

    $user_message = isset($_POST['message']) ? sanitize_text_field(wp_unslash($_POST['message'])) : '';
    $settings = get_option('nafcorp_ai_intake_settings');
    $api_key = $settings['api_key'] ?? '';
    $voice = $settings['voice'] ?? 'alloy';
    $enable_tts = $settings['enable_tts'] ?? true;
    $system_prompt = $settings['system_prompt'] ?? 'You are a website intake assistant. Help users plan their website by asking smart questions about their business goals, target audience, desired features, and design preferences.';
    $model = $settings['model'] ?? 'gpt-4o';
    $temperature = $settings['temperature'] ?? 0.7;
    $max_tokens = $settings['max_tokens'] ?? 500;

    if (empty($api_key)) {
        wp_send_json_error(['error' => 'API key not set.']);
        return;
    }

    // Manage conversation history
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['chat_history'])) {
        $_SESSION['chat_history'] = [
            ['role' => 'system', 'content' => $system_prompt]
        ];
    }
    
    // Add user message to history
    $_SESSION['chat_history'][] = ['role' => 'user', 'content' => $user_message];
    
    // Keep only last 10 messages to avoid token limits
    $current_history = isset($_SESSION['chat_history']) ? (array) $_SESSION['chat_history'] : [];

    if (count($current_history) > 20) {
        $clean_history = array_map(function($item) {
            return [
                'role'    => isset($item['role']) ? sanitize_text_field($item['role']) : '',
                'content' => isset($item['content']) ? sanitize_textarea_field($item['content']) : ''
            ];
        }, $current_history);

        $_SESSION['chat_history'] = array_merge(
            [['role' => 'system', 'content' => $system_prompt]],
            array_slice($clean_history, -19)
        );
    }

    // Get text response from OpenAI
    $chat_url = 'https://api.openai.com/v1/chat/completions';
    
    // Sanitize chat history before sending to API
    $sanitized_messages = [];
    
    if (isset($_SESSION['chat_history']) && is_array($_SESSION['chat_history'])) {
        $sanitized_messages = array_map(function($item) {
            return [
                'role'    => isset($item['role']) ? sanitize_text_field($item['role']) : '',
                'content' => isset($item['content']) ? sanitize_textarea_field($item['content']) : ''
            ];
        }, (array) $_SESSION['chat_history']);
    }
    
    $chat_data = [
        'model' => $model,
        'messages' => $sanitized_messages,
        'temperature' => (float) $temperature,
        'max_tokens' => (int) $max_tokens
    ];

    $chat_response = wp_remote_post($chat_url, [
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key,
        ],
        'body' => json_encode($chat_data),
        'timeout' => 60,
    ]);

    if (is_wp_error($chat_response)) {
        wp_send_json_error(['error' => 'Failed to connect to OpenAI: ' . $chat_response->get_error_message()]);
        return;
    }

    $body = json_decode(wp_remote_retrieve_body($chat_response), true);
    
    if (!isset($body['choices'][0]['message']['content'])) {
        $error_msg = $body['error']['message'] ?? 'Invalid response from OpenAI';
        wp_send_json_error(['error' => $error_msg]);
        return;
    }
    
    $reply = $body['choices'][0]['message']['content'];
    
    // Add assistant reply to history
    $_SESSION['chat_history'][] = ['role' => 'assistant', 'content' => $reply];

    // Generate TTS audio (optional)
    $audio_url = '';
    if ($enable_tts) {
        $audio_url = nafcorp_generate_tts($reply, $voice, $api_key);
    }

    wp_send_json_success([
        'reply' => $reply,
        'audio_url' => $audio_url
    ]);
}

// ============================================
// TTS GENERATION FUNCTION
// ============================================

/**
 * Generate Text-to-Speech audio using OpenAI TTS API
 * 
 * @param string $text The text to convert to speech
 * @param string $voice The voice to use (alloy, echo, fable, onyx, nova, shimmer)
 * @param string $api_key OpenAI API key
 * @return string URL to the generated audio file, or empty string on failure
 */
function nafcorp_generate_tts($text, $voice, $api_key) {
    try {
        // Don't generate TTS for very long texts (save costs)
        if (strlen($text) > 4096) {
            $text = substr($text, 0, 4096);
        }
        
        // Skip empty text
        if (empty(trim($text))) {
            return '';
        }
        
        $tts_url = 'https://api.openai.com/v1/audio/speech';
        $tts_data = [
            'model' => 'tts-1',
            'input' => $text,
            'voice' => $voice,
            'response_format' => 'mp3'
        ];

        $upload_dir = wp_upload_dir();
        $audio_dir = $upload_dir['basedir'] . '/nafcorp-ai/';
        
        if (!file_exists($audio_dir)) {
            wp_mkdir_p($audio_dir);
        }

        $file_name = 'audio_' . time() . '_' . wp_rand(1000, 9999) . '.mp3';
        $file_path = $audio_dir . $file_name;
        $file_url = $upload_dir['baseurl'] . '/nafcorp-ai/' . $file_name;

        $tts_response = wp_remote_post($tts_url, [
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ],
            'body' => json_encode($tts_data),
            'timeout' => 60,
        ]);

        if (!is_wp_error($tts_response) && wp_remote_retrieve_response_code($tts_response) === 200) {
            $audio_data = wp_remote_retrieve_body($tts_response);
            if (!empty($audio_data)) {
                // Use WordPress filesystem API
                global $wp_filesystem;
                if (empty($wp_filesystem)) {
                    require_once ABSPATH . '/wp-admin/includes/file.php';
                    WP_Filesystem();
                }
                
                if ($wp_filesystem) {
                    $wp_filesystem->put_contents($file_path, $audio_data, FS_CHMOD_FILE);
                } else {
                    // Fallback to file_put_contents
                    file_put_contents($file_path, $audio_data);
                }
                
                // Schedule cleanup of old audio files
                if (!wp_next_scheduled('nafcorp_cleanup_audio_files')) {
                    wp_schedule_single_event(time() + 3600, 'nafcorp_cleanup_audio_files');
                }
                
                return $file_url;
            }
        } else {
            // Log error for debugging
            if (defined('WP_DEBUG') && WP_DEBUG) {
                $error_body = wp_remote_retrieve_body($tts_response);
                error_log('NAFCORP TTS Error: ' . $error_body);
            }
        }
    } catch (Exception $e) {
        // Log error for debugging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('NAFCORP TTS Exception: ' . $e->getMessage());
        }
    }
    
    return '';
}

// Cleanup old audio files
add_action('nafcorp_cleanup_audio_files', 'nafcorp_cleanup_audio_files_handler');
function nafcorp_cleanup_audio_files_handler() {
    $upload_dir = wp_upload_dir();
    $audio_dir = $upload_dir['basedir'] . '/nafcorp-ai/';
    
    if (is_dir($audio_dir)) {
        $files = glob($audio_dir . 'audio_*.mp3');
        $now = time();
        
        if ($files) {
            foreach ($files as $file) {
                if ($now - filemtime($file) >= 3600) { // 1 hour old
                    wp_delete_file($file);
                }
            }
        }
    }
}

// ============================================
// SPEECH-TO-TEXT (WHISPER API)
// ============================================

add_action('wp_ajax_nafcorp_ai_speech_to_text', 'nafcorp_ai_speech_to_text');
add_action('wp_ajax_nopriv_nafcorp_ai_speech_to_text', 'nafcorp_ai_speech_to_text');

function nafcorp_ai_speech_to_text() {
    check_ajax_referer('nafcorp_ai_nonce', 'nonce');
    
    // VALIDATION: Check if file exists and handle errors
    if (empty($_FILES['audio']) || empty($_FILES['audio']['tmp_name'])) {
        wp_send_json_error(['error' => 'No audio file received.']);
        return;
    }

    // Check for upload errors
    if (isset($_FILES['audio']['error']) && $_FILES['audio']['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error(['error' => 'Upload error code: ' . intval($_FILES['audio']['error'])]);
        return;
    }
    
    $settings = get_option('nafcorp_ai_intake_settings');
    $api_key = $settings['api_key'] ?? '';
    
    if (empty($api_key)) {
        wp_send_json_error(['error' => 'API key not set.']);
        return;
    }
    
    $file_path = isset($_FILES['audio']['tmp_name']) ? sanitize_text_field(wp_unslash($_FILES['audio']['tmp_name'])) : '';
    $file_name = isset($_FILES['audio']['name']) ? sanitize_file_name(wp_unslash($_FILES['audio']['name'])) : 'recording.webm';
    $file_type = isset($_FILES['audio']['type']) ? sanitize_mime_type(wp_unslash($_FILES['audio']['type'])) : 'audio/webm';

    // OPENAI WHISPER API VIA WP_REMOTE_POST (Multipart workaround)
    $boundary = '----WebKitFormBoundary' . md5(time());
    $headers = [
        'Authorization' => 'Bearer ' . $api_key,
        'Content-Type'  => 'multipart/form-data; boundary=' . $boundary,
    ];

    $payload = '';
    
    // Add file field
    $file_content = file_get_contents($file_path);
    $payload .= "--" . $boundary . "\r\n";
    $payload .= 'Content-Disposition: form-data; name="file"; filename="' . $file_name . '"' . "\r\n";
    $payload .= 'Content-Type: ' . $file_type . "\r\n\r\n";
    $payload .= $file_content . "\r\n";

    // Add model field
    $payload .= "--" . $boundary . "\r\n";
    $payload .= 'Content-Disposition: form-data; name="model"' . "\r\n\r\n";
    $payload .= "whisper-1\r\n";

    // Close boundary
    $payload .= "--" . $boundary . "--\r\n";

    $response = wp_remote_post('https://api.openai.com/v1/audio/transcriptions', [
        'headers' => $headers,
        'body'    => $payload,
        'timeout' => 60,
    ]);
    
    if (is_wp_error($response)) {
        wp_send_json_error(['error' => 'Failed to connect to OpenAI: ' . $response->get_error_message()]);
        return;
    }

    $response_code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    if ($response_code !== 200) {
        wp_send_json_error(['error' => 'API Error: ' . ($body['error']['message'] ?? 'Unknown error')]);
        return;
    }
    
    if (!isset($body['text']) || empty($body['text'])) {
        wp_send_json_error(['error' => 'No text was recognized in the audio.']);
        return;
    }
    
    wp_send_json_success(['text' => sanitize_text_field($body['text'])]);
}

// ============================================
// REALTIME API TOKEN (Future Implementation)
// ============================================

add_action('wp_ajax_nafcorp_ai_get_realtime_token', 'nafcorp_ai_get_realtime_token');
function nafcorp_ai_get_realtime_token() {
    // Verify nonce - check both new and legacy nonces
    $nonce = isset($_GET['nonce']) ? sanitize_text_field(wp_unslash($_GET['nonce'])) : '';
    $nonce_verified = false;
    
    if (wp_verify_nonce($nonce, 'nafcorp_chat_nonce')) {
        $nonce_verified = true;
    } elseif (wp_verify_nonce($nonce, 'nafcorp_ai_nonce')) {
        $nonce_verified = true;
    }
    
    if (!$nonce_verified) {
        wp_send_json_error(['error' => 'Invalid security token.']);
        return;
    }
    
    $settings = get_option('nafcorp_ai_intake_settings', []);
    $api_key = $settings['api_key'] ?? '';
    
    if (empty($api_key)) {
        wp_send_json_error(['error' => 'API key not set in plugin settings.']);
        return;
    }
    
    // Create an ephemeral token
    $response = wp_remote_post('https://api.openai.com/v1/realtime/sessions', [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json',
        ],
        'body' => json_encode([
            'model' => 'gpt-realtime-mini',
            'voice' => $settings['voice'] ?? 'verse',
        ]),
        'timeout' => 30
    ]);

    if (is_wp_error($response)) {
        wp_send_json_error(['error' => 'Failed to connect to OpenAI: ' . $response->get_error_message()]);
        return;
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    
    if (isset($body['client_secret']['value'])) {
        wp_send_json_success(['client_secret' => $body['client_secret']['value']]);
    } else {
        wp_send_json_error(['error' => 'Failed to generate ephemeral token.', 'details' => $body]);
    }
}

// ============================================
// ADMIN MENU & SETTINGS PAGE
// ============================================

function nafcorp_ai_intake_register_menu() {
    add_menu_page(
        'DeepConvo AI Settings', 
        'DeepConvo AI', 
        'manage_options',
        'nafcorp-ai-intake-settings', 
        'nafcorp_ai_intake_settings_page', 
        'dashicons-admin-generic'
    );
}
add_action('admin_menu', 'nafcorp_ai_intake_register_menu');

function nafcorp_ai_intake_settings_page() {
    require_once plugin_dir_path(__FILE__) . 'admin/settings-page.php';
}

// ============================================
// CHAT SESSION MANAGEMENT
// ============================================

// Reset chat session
add_action('wp_ajax_nafcorp_ai_reset_chat', 'nafcorp_ai_reset_chat');
add_action('wp_ajax_nopriv_nafcorp_ai_reset_chat', 'nafcorp_ai_reset_chat');

function nafcorp_ai_reset_chat() {
    check_ajax_referer('nafcorp_ai_nonce', 'nonce');
    
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    unset($_SESSION['chat_history']);
    unset($_SESSION['nafcorp_last_response_id']); // Clear Responses API response ID
    
    wp_send_json_success(['message' => 'Chat session reset']);
}

// Delete knowledge file
add_action('wp_ajax_nafcorp_delete_knowledge_file', 'nafcorp_delete_knowledge_file');

function nafcorp_delete_knowledge_file() {
    check_admin_referer('nafcorp_delete_file', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['error' => 'Unauthorized']);
        return;
    }
    
    $settings = get_option('nafcorp_ai_intake_settings', []);
    $api_key = $settings['api_key'] ?? '';
    
    // Delete from OpenAI
    if (!empty($api_key)) {
        if (!empty($settings['openai_file_id'])) {
            wp_remote_request('https://api.openai.com/v1/files/' . $settings['openai_file_id'], [
                'headers' => ['Authorization' => 'Bearer ' . $api_key],
                'method' => 'DELETE',
                'timeout' => 15
            ]);
        }
        
        if (!empty($settings['openai_vector_store_id'])) {
            wp_remote_request('https://api.openai.com/v1/vector_stores/' . $settings['openai_vector_store_id'], [
                'headers' => [
                    'Authorization' => 'Bearer ' . $api_key,
                    'OpenAI-Beta' => 'assistants=v2'
                ],
                'method' => 'DELETE',
                'timeout' => 15
            ]);
        }
    }
    
    // Delete local file
    if (!empty($settings['knowledge_file_path']) && file_exists($settings['knowledge_file_path'])) {
        wp_delete_file($settings['knowledge_file_path']);
    }
    
    // Clear settings
    $settings['knowledge_file_path'] = '';
    $settings['knowledge_file_url'] = '';
    $settings['openai_file_id'] = '';
    $settings['openai_vector_store_id'] = '';
    $settings['needs_openai_sync'] = false;
    
    update_option('nafcorp_ai_intake_settings', $settings);
    
    wp_send_json_success(['message' => 'Knowledge file deleted successfully']);
}

// Export chat history
add_action('wp_ajax_nafcorp_ai_export_chat', 'nafcorp_ai_export_chat');
add_action('wp_ajax_nopriv_nafcorp_ai_export_chat', 'nafcorp_ai_export_chat');

function nafcorp_ai_export_chat() {
    check_ajax_referer('nafcorp_ai_nonce', 'nonce');
    
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Sanitize session data before export
    $history = [];
    
    if (isset($_SESSION['chat_history']) && is_array($_SESSION['chat_history'])) {
        $history = array_map(function($item) {
            return [
                'role'    => isset($item['role']) ? sanitize_text_field($item['role']) : '',
                'content' => isset($item['content']) ? sanitize_textarea_field($item['content']) : ''
            ];
        }, (array) $_SESSION['chat_history']);
    }
    
    $export_data = [
        'timestamp' => current_time('mysql'),
        'conversation' => $history
    ];
    
    wp_send_json_success($export_data);
}

// ============================================
// PLUGIN ACTIVATION/DEACTIVATION
// ============================================

register_activation_hook(__FILE__, 'nafcorp_ai_intake_activate');
function nafcorp_ai_intake_activate() {
    // Create default settings
    $default_settings = [
        'api_key' => '',
        'voice' => 'alloy',
        'system_prompt' => 'You are a website intake assistant. Help users plan their website by asking smart questions about their business goals, target audience, desired features, and design preferences.',
        'enable_tts' => true,
        'use_realtime' => false,
        'model' => 'gpt-4o',
        'temperature' => 0.7,
        'max_tokens' => 500,
        'bot_name' => 'AI Assistant',
        'opening_message' => 'Hello! How can I help you today?',
        'primary_color' => '#1DFF85',
        'position' => 'right',
        'enable_file_search' => false,
        'enable_code_interpreter' => false
    ];
    
    if (!get_option('nafcorp_ai_intake_settings')) {
        add_option('nafcorp_ai_intake_settings', $default_settings);
    }
    
    // Create audio directory
    $upload_dir = wp_upload_dir();
    $audio_dir = $upload_dir['basedir'] . '/nafcorp-ai/';
    if (!file_exists($audio_dir)) {
        wp_mkdir_p($audio_dir);
    }
    
    // Schedule cleanup for old audio files
    if (!wp_next_scheduled('nafcorp_cleanup_audio_files')) {
        wp_schedule_event(time(), 'daily', 'nafcorp_cleanup_audio_files');
    }
}

register_deactivation_hook(__FILE__, 'nafcorp_ai_intake_deactivate');
function nafcorp_ai_intake_deactivate() {
    // Clean up scheduled events
    wp_clear_scheduled_hook('nafcorp_cleanup_audio_files');
    
    // Optionally clean up audio files
    $upload_dir = wp_upload_dir();
    $audio_dir = $upload_dir['basedir'] . '/nafcorp-ai/';
    
    if (is_dir($audio_dir)) {
        $files = glob($audio_dir . 'audio_*.mp3');
        if ($files) {
            foreach ($files as $file) {
                wp_delete_file($file);
            }
        }
    }
}

// Allow JSON file uploads for Knowledge Base
function nafcorp_allow_json_uploads($mimes) {
    $mimes['json'] = 'application/json';
    return $mimes;
}
add_filter('upload_mimes', 'nafcorp_allow_json_uploads');