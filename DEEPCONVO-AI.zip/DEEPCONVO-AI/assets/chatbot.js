/**
 * WPAssistant NT - Futuristic Chatbot Interface
 * High-fidelity UI with bioluminescent effects
 * @version 2.3 - With Dynamic Settings, Conversation Starters & Full TTS Support
 */

jQuery(document).ready(function($) {
    
    // ============================================
    // DYNAMIC CONFIGURATION
    // ============================================
    
    const config = window.nafcorpSettings || {};
    const legacyConfig = window.nafcorpAI || {};
    
    // Merge configs (new settings take priority)
    const ajaxUrl = config.ajax_url || legacyConfig.ajax_url;
    const chatNonce = config.nonce || legacyConfig.nonce;
    const legacyNonce = legacyConfig.nonce;
    const enableTts = config.enable_tts !== undefined ? config.enable_tts : (legacyConfig.enable_tts !== undefined ? legacyConfig.enable_tts : true);
    
    // Apply Dynamic CSS Variables (Brand Color, Position)
    if (config.primaryColor) {
        document.documentElement.style.setProperty('--accent-primary', config.primaryColor);
        document.documentElement.style.setProperty('--accent-glow', config.primaryColor + '99');
    }
    
    // ============================================
    // CREATE UI ELEMENTS
    // ============================================
    
    // Update bot name in header
    const botName = config.botName || 'AI Assistant';
    
    // Bubble Button with animated icon
    const bubbleButton = $(`
        <div id="nafcorp-chat-bubble" role="button" aria-label="Open chat assistant" tabindex="0">
            <div class="nafcorp-bubble-icon">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 2H4C2.9 2 2 2.9 2 4V22L6 18H20C21.1 18 22 17.1 22 16V4C22 2.9 21.1 2 20 2Z" fill="currentColor"/>
                    <circle cx="8" cy="10" r="1.5" fill="#000"/>
                    <circle cx="12" cy="10" r="1.5" fill="#000"/>
                    <circle cx="16" cy="10" r="1.5" fill="#000"/>
                </svg>
            </div>
            <div class="nafcorp-bubble-notification" aria-hidden="true"></div>
        </div>
    `);
    
    // Main Chat Widget
    const chatWidget = $(`
        <div id="nafcorp-chat-widget" class="nafcorp-chat-closed" role="dialog" aria-label="Chat assistant">
            <div class="nafcorp-chat-header">
                <div class="nafcorp-header-content">
                    <div class="nafcorp-header-avatar" aria-hidden="true">
                        <!-- Bioluminescent orb rendered via CSS -->
                    </div>
                    <div class="nafcorp-header-info">
                        <h3>${botName}</h3>
                        <span class="nafcorp-status-text">Online</span>
                    </div>
                </div>
                <button class="nafcorp-close-btn" aria-label="Close chat">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </button>
            </div>
            
            <div id="nafcorp-chatbox" role="log" aria-live="polite" aria-relevant="additions"></div>
            
            <div class="nafcorp-input-area">
                <input type="text" id="nafcorp-chat-input" placeholder="Type your message..." aria-label="Chat message input" autocomplete="off" />
                <button id="nafcorp-send-btn" aria-label="Send message">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22 2L11 13M22 2L15 22L11 13M22 2L2 9L11 13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
                <button id="nafcorp-mic-btn" aria-label="Start voice input">
                    <svg class="mic-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2C10.34 2 9 3.34 9 5V11C9 12.66 10.34 14 12 14C13.66 14 15 12.66 15 11V5C15 3.34 13.66 2 12 2Z" fill="currentColor"/>
                        <path d="M17 11C17 13.76 14.76 16 12 16C9.24 16 7 13.76 7 11H5C5 14.53 7.61 17.43 11 17.92V21H13V17.92C16.39 17.43 19 14.53 19 11H17Z" fill="currentColor"/>
                    </svg>
                    <svg class="stop-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: none;">
                        <rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/>
                    </svg>
                </button>
            </div>
            
            <div class="nafcorp-footer-controls">
                <button class="nafcorp-control-btn" id="nafcorp-theme-btn" aria-label="Toggle theme">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 3V4M12 20V21M4 12H3M6.31 6.31L5.6 5.6M17.69 6.31L18.4 5.6M6.31 17.69L5.6 18.4M17.69 17.69L18.4 18.4M21 12H20M16 12C16 14.21 14.21 16 12 16C9.79 16 8 14.21 8 12C8 9.79 9.79 8 12 8C14.21 8 16 9.79 16 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                    Theme
                </button>
                <button class="nafcorp-control-btn" id="nafcorp-reset-btn" aria-label="Reset conversation">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 4V10H7M23 20V14H17M20.49 9C19.79 6.83 18.29 5.01 16.29 3.93C14.29 2.85 11.95 2.6 9.77 3.22C7.59 3.84 5.73 5.29 4.57 7.27C3.41 9.25 3.04 11.6 3.54 13.85M0.51 15.05C1.03 17.28 2.4 19.22 4.36 20.41C6.32 21.6 8.66 21.95 10.87 21.39C13.08 20.83 14.99 19.41 16.2 17.43C17.41 15.45 17.82 13.08 17.35 10.8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Reset
                </button>
                <button class="nafcorp-control-btn" id="nafcorp-export-btn" aria-label="Export conversation">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M21 15V19C21 19.53 20.79 20.04 20.41 20.41C20.04 20.79 19.53 21 19 21H5C4.47 21 3.96 20.79 3.59 20.41C3.21 20.04 3 19.53 3 19V15M7 10L12 15M12 15L17 10M12 15V3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Export
                </button>
            </div>
        </div>
    `);
    
    // Append to body
    $('body').append(bubbleButton, chatWidget);
    
    // Apply Widget Position
    if (config.position === 'left') {
        $('#nafcorp-chat-widget').css({ right: 'auto', left: '24px' });
        $('#nafcorp-chat-bubble').css({ right: 'auto', left: '24px' });
    }
    
    // ============================================
    // ELEMENT REFERENCES
    // ============================================
    
    const chatBox = $('#nafcorp-chatbox');
    const inputBox = $('#nafcorp-chat-input');
    const sendButton = $('#nafcorp-send-btn');
    const micButton = $('#nafcorp-mic-btn');
    const resetButton = $('#nafcorp-reset-btn');
    const exportButton = $('#nafcorp-export-btn');
    const themeButton = $('#nafcorp-theme-btn');
    const closeButton = $('.nafcorp-close-btn');
    
    // ============================================
    // STATE MANAGEMENT
    // ============================================
    
    let isChatOpen = false;
    let isFirstOpen = true;
    let isRecording = false;
    let mediaRecorder = null;
    let recordedChunks = [];
    let recordingStream = null;
    let isDarkMode = true;
    let isLimitReached = false;
    let currentAudio = null; // Track current playing audio
    
    // Realtime API State
    let peerConnection = null;
    let dataChannel = null;
    let realtimeAudioElement = null;
    let isRealtimeActive = false;
    
    // ============================================
    // CONVERSATION STARTERS
    // ============================================
    
    function renderConversationStarters() {
        if (!config.starters || config.starters.length === 0) return;
        
        const starterContainer = $('<div class="nafcorp-starters"></div>');
        
        config.starters.forEach(text => {
            if (!text || text.trim() === '') return;
            
            const btn = $('<button class="starter-btn"></button>').text(text.trim());
            btn.on('click', function() {
                sendMessage(text.trim());
                starterContainer.fadeOut(300, function() {
                    $(this).remove();
                });
            });
            starterContainer.append(btn);
        });
        
        chatBox.append(starterContainer);
    }
    
    // ============================================
    // CHAT TOGGLE FUNCTIONALITY
    // ============================================
    
    function toggleChat() {
        isChatOpen = !isChatOpen;
        
        if (isChatOpen) {
            chatWidget.removeClass('nafcorp-chat-closed').addClass('nafcorp-chat-open');
            bubbleButton.addClass('nafcorp-bubble-hidden');
            
            // Focus input with delay for animation
            setTimeout(() => {
                inputBox.focus();
            }, 400);
            
            // Welcome message and starters on first open
            if (isFirstOpen) {
                isFirstOpen = false;
                setTimeout(() => {
                    const welcomeMsg = config.openingMsg || "Welcome! I'm here to help you plan your project. Type a message or use the microphone for voice input.";
                    addMessage(welcomeMsg, "bot");
                    
                    // Render conversation starters after welcome message
                    setTimeout(renderConversationStarters, 300);
                }, 600);
            }
        } else {
            chatWidget.removeClass('nafcorp-chat-open').addClass('nafcorp-chat-closed');
            setTimeout(() => {
                bubbleButton.removeClass('nafcorp-bubble-hidden');
            }, 300);
            
            // Stop any playing audio when closing chat
            if (currentAudio) {
                currentAudio.pause();
                currentAudio = null;
            }
        }
    }
    
    // Event listeners for toggle
    bubbleButton.on('click keypress', function(e) {
        if (e.type === 'click' || e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            toggleChat();
            $('.nafcorp-bubble-notification').removeClass('show');
        }
    });
    
    closeButton.on('click', toggleChat);
    
    // Escape key to close
    $(document).on('keydown', function(e) {
        if (e.key === 'Escape' && isChatOpen) {
            toggleChat();
        }
    });
    
    // ============================================
    // MESSAGE HANDLING
    // ============================================
    
    function addMessage(message, sender = 'user') {
        const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const msg = $('<div class="nafcorp-message"></div>')
            .text(message)
            .addClass(sender)
            .attr('data-time', timestamp);
        
        chatBox.append(msg);
        
        // Smooth scroll to bottom
        chatBox.animate({
            scrollTop: chatBox.prop('scrollHeight')
        }, 300);
        
        // Show notification if chat is closed
        if (!isChatOpen && sender === 'bot') {
            $('.nafcorp-bubble-notification').addClass('show');
        }
        
        return msg;
    }
    
    /**
     * Play TTS audio response
     * @param {string} audioUrl URL to the audio file
     */
    function playTtsAudio(audioUrl) {
        if (!audioUrl || !enableTts) {
            return;
        }
        
        // Stop any currently playing audio
        if (currentAudio) {
            currentAudio.pause();
            currentAudio = null;
        }
        
        try {
            currentAudio = new Audio(audioUrl);
            currentAudio.volume = 0.8;
            
            // Add event listeners for better UX
            currentAudio.addEventListener('ended', function() {
                currentAudio = null;
            });
            
            currentAudio.addEventListener('error', function(e) {
                console.log('Audio playback error:', e);
                currentAudio = null;
            });
            
            // Play the audio
            const playPromise = currentAudio.play();
            
            if (playPromise !== undefined) {
                playPromise.catch(err => {
                    console.log('Audio autoplay prevented:', err);
                    // Browser may block autoplay - this is expected behavior
                    currentAudio = null;
                });
            }
        } catch (err) {
            console.log('Audio initialization error:', err);
        }
    }
    
    /**
     * Show upgrade prompt when free tier is exhausted
     */
    function showUpgradePrompt(data) {
        isLimitReached = true;
        
        const upgradeHtml = $(`
            <div class="nafcorp-message upgrade-prompt">
                <div class="upgrade-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" fill="currentColor"/>
                    </svg>
                </div>
                <div class="upgrade-content">
                    <h4>Free Tier Limit Reached</h4>
                    <p>You've used all ${data.prompts_limit || 5} free prompts this month.</p>
                    <p>Upgrade to unlock unlimited conversations!</p>
                    <a href="${data.upgrade_url || 'https://www.nafcorp.com.au/wpassistant-pricing'}" 
                       target="_blank" 
                       class="upgrade-btn">
                        Upgrade Now
                    </a>
                </div>
            </div>
        `);
        
        chatBox.append(upgradeHtml);
        chatBox.animate({
            scrollTop: chatBox.prop('scrollHeight')
        }, 300);
        
        // Disable input
        inputBox.prop('disabled', true).attr('placeholder', 'Upgrade to continue chatting...');
        sendButton.prop('disabled', true);
        micButton.prop('disabled', true);
    }
    
    function showTypingIndicator() {
        const typing = $(`
            <div class="nafcorp-typing" aria-label="Assistant is typing">
                <span></span>
                <span></span>
                <span></span>
            </div>
        `);
        chatBox.append(typing);
        chatBox.animate({
            scrollTop: chatBox.prop('scrollHeight')
        }, 300);
        return typing;
    }
    
    function setLoadingState(isLoading) {
        sendButton.prop('disabled', isLoading || isLimitReached).toggleClass('loading', isLoading);
        micButton.prop('disabled', isLoading || isLimitReached);
        inputBox.prop('disabled', isLoading || isLimitReached);
        
        if (isLoading) {
            sendButton.attr('aria-busy', 'true');
        } else {
            sendButton.removeAttr('aria-busy');
        }
    }
    
    // ============================================
    // API COMMUNICATION
    // ============================================
    
    function sendMessage(text) {
        if (!text || !text.trim() || isLimitReached) return;
        
        text = text.trim();
        addMessage(text, 'user');
        inputBox.val('');
        setLoadingState(true);
        
        const typingIndicator = showTypingIndicator();
        
        // Try new Assistants API endpoint first, fallback to legacy
        $.post(ajaxUrl, {
            action: 'nafcorp_chat_message', // New Assistants API endpoint
            nonce: chatNonce,
            message: text
        })
        .done(function(response) {
            typingIndicator.remove();
            setLoadingState(false);
            
            if (response.success) {
                addMessage(response.data.reply, 'bot');
                
                // Play TTS audio if available
                if (response.data.audio_url) {
                    playTtsAudio(response.data.audio_url);
                }
            } else {
                // Check for tier limit errors
                if (response.data && response.data.limit_reached) {
                    isLimitReached = true;
                    showUpgradePrompt(response.data);
                } else if (response.data && response.data.not_registered) {
                    addMessage('⚠️ Registration required. Please register your API key in the plugin settings.', 'system');
                } else if (response.data && response.data.tier && response.data.prompts_used >= response.data.prompts_limit) {
                    isLimitReached = true;
                    showUpgradePrompt(response.data);
                } else {
                    addMessage(response.data.error || 'An error occurred. Please try again.', 'system');
                }
            }
        })
        .fail(function(xhr, status, error) {
            // Fallback to legacy API if new endpoint doesn't exist
            if (xhr.status === 400 || xhr.status === 404) {
                tryLegacyAPI(text, typingIndicator);
            } else {
                typingIndicator.remove();
                setLoadingState(false);
                addMessage('Connection error. Please check your internet and try again.', 'system');
            }
        });
    }
    
    // Fallback to legacy nafcorp_ai_chat action
    function tryLegacyAPI(text, typingIndicator) {
        $.post(legacyConfig.ajax_url || ajaxUrl, {
            action: 'nafcorp_ai_chat',
            nonce: legacyNonce || chatNonce,
            message: text
        })
        .done(function(response) {
            typingIndicator.remove();
            setLoadingState(false);
            
            if (response.success) {
                addMessage(response.data.reply, 'bot');
                
                // Play TTS audio if available
                if (response.data.audio_url) {
                    playTtsAudio(response.data.audio_url);
                }
            } else {
                if (response.data && response.data.tier && response.data.prompts_used >= response.data.prompts_limit) {
                    isLimitReached = true;
                    showUpgradePrompt(response.data);
                } else {
                    addMessage(response.data.error || 'An error occurred. Please try again.', 'system');
                }
            }
        })
        .fail(function() {
            typingIndicator.remove();
            setLoadingState(false);
            addMessage('Connection error. Please check your internet and try again.', 'system');
        });
    }
    
    // ============================================
    // REALTIME API (WebRTC)
    // ============================================
    
    async function startRealtimeSession() {
        if (isLimitReached) {
            addMessage("Please upgrade to continue using voice input.", "system");
            return false;
        }
        
        try {
            // Update UI to loading state
            micButton.addClass('recording'); // Use recording style for active state
            micButton.find('.mic-icon').hide();
            micButton.find('.stop-icon').hide(); // Hide stop icon while loading
            micButton.addClass('loading'); // Add loading spinner
            
            // 1. Get Ephemeral Token from Backend
            const tokenResponse = await $.post(ajaxUrl, {
                action: 'nafcorp_ai_get_realtime_token',
                nonce: chatNonce
            });
            
            if (!tokenResponse.success) {
                throw new Error(tokenResponse.data.error || 'Failed to get realtime token');
            }
            
            const EPHEMERAL_KEY = tokenResponse.data.client_secret;
            
            // 2. Initialize WebRTC Peer Connection
            peerConnection = new RTCPeerConnection();
            
            // Set up remote audio playback
            realtimeAudioElement = document.createElement("audio");
            realtimeAudioElement.autoplay = true;
            peerConnection.ontrack = (e) => {
                realtimeAudioElement.srcObject = e.streams[0];
            };
            
            // 3. Add Local Microphone Track
            const ms = await navigator.mediaDevices.getUserMedia({
                audio: true
            });
            peerConnection.addTrack(ms.getTracks()[0]);
            
            // 4. Create Data Channel for Events
            dataChannel = peerConnection.createDataChannel("oai-events");
            dataChannel.addEventListener("message", (e) => {
                try {
                    const event = JSON.parse(e.data);
                    // Handle server events if needed (e.g. transcriptions)
                    if (event.type === 'response.audio_transcript.done') {
                        addMessage(event.transcript, 'bot');
                    } else if (event.type === 'conversation.item.input_audio_transcription.completed') {
                        addMessage(event.transcript, 'user');
                    }
                } catch (err) {
                    console.log('Event parse error:', err);
                }
            });
            
            // 5. Create Offer and Connect
            const offer = await peerConnection.createOffer();
            await peerConnection.setLocalDescription(offer);
            
            const baseUrl = "https://api.openai.com/v1/realtime";
            const model = "gpt-4o-realtime-mini-preview-2024-12-17";
            
            const sdpResponse = await fetch(`${baseUrl}?model=${model}`, {
                method: "POST",
                body: offer.sdp,
                headers: {
                    Authorization: `Bearer ${EPHEMERAL_KEY}`,
                    "Content-Type": "application/sdp",
                },
            });
            
            const answer = {
                type: "answer",
                sdp: await sdpResponse.text(),
            };
            await peerConnection.setRemoteDescription(answer);
            
            isRealtimeActive = true;
            
            // Update UI to active state
            micButton.removeClass('loading');
            micButton.find('.stop-icon').show();
            micButton.attr('aria-label', 'Stop voice conversation');
            addMessage("Voice conversation active. Speak now...", "system");
            
            return true;
            
        } catch (err) {
            console.error("Realtime session error:", err);
            stopRealtimeSession();
            addMessage("Failed to start voice session: " + err.message, "system");
            return false;
        }
    }
    
    function stopRealtimeSession() {
        if (peerConnection) {
            peerConnection.close();
            peerConnection = null;
        }
        
        if (dataChannel) {
            dataChannel.close();
            dataChannel = null;
        }
        
        if (realtimeAudioElement) {
            realtimeAudioElement.srcObject = null;
            realtimeAudioElement = null;
        }
        
        isRealtimeActive = false;
        
        // Reset UI
        micButton.removeClass('recording loading');
        micButton.find('.mic-icon').show();
        micButton.find('.stop-icon').hide();
        micButton.attr('aria-label', 'Start voice input');
        
        // Remove "Voice conversation active" message
        chatBox.find('.nafcorp-message.system:contains("Voice conversation active")').remove();
    }

    // ============================================
    // VOICE RECORDING (Speech-to-Text)
    // ============================================
    
    async function startRecording() {
        if (isLimitReached) {
            addMessage("Please upgrade to continue using voice input.", "system");
            return false;
        }
        
        try {
            recordingStream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true,
                    sampleRate: 44100
                }
            });
            
            mediaRecorder = new MediaRecorder(recordingStream, {
                mimeType: MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/mp4'
            });
            
            recordedChunks = [];
            
            mediaRecorder.ondataavailable = function(e) {
                if (e.data.size > 0) {
                    recordedChunks.push(e.data);
                }
            };
            
            mediaRecorder.onstop = function() {
                const audioBlob = new Blob(recordedChunks, { type: mediaRecorder.mimeType });
                sendAudioToServer(audioBlob);
                recordedChunks = [];
            };
            
            mediaRecorder.start();
            isRecording = true;
            
            // Update UI
            micButton.addClass('recording');
            micButton.find('.mic-icon').hide();
            micButton.find('.stop-icon').show();
            micButton.attr('aria-label', 'Stop recording');
            
            addMessage("Listening... Tap again when done.", "system");
            
            return true;
        } catch (err) {
            console.error("Microphone access error:", err);
            addMessage("Microphone access denied. Please enable permissions.", "system");
            return false;
        }
    }
    
    function stopRecording() {
        if (!isRecording || !mediaRecorder) return;
        
        isRecording = false;
        mediaRecorder.stop();
        
        if (recordingStream) {
            recordingStream.getTracks().forEach(track => track.stop());
            recordingStream = null;
        }
        
        // Update UI
        micButton.removeClass('recording');
        micButton.find('.mic-icon').show();
        micButton.find('.stop-icon').hide();
        micButton.attr('aria-label', 'Start voice input');
        
        addMessage("Processing your voice...", "system");
        setLoadingState(true);
    }
    
    function sendAudioToServer(audioBlob) {
        const formData = new FormData();
        formData.append('action', 'nafcorp_ai_speech_to_text');
        formData.append('nonce', legacyNonce || chatNonce);
        formData.append('audio', audioBlob, 'recording.webm');
        
        $.ajax({
            url: legacyConfig.ajax_url || ajaxUrl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false
        })
        .done(function(response) {
            setLoadingState(false);
            
            if (response.success && response.data.text) {
                // Remove the "processing" message
                chatBox.find('.nafcorp-message.system').last().remove();
                sendMessage(response.data.text);
            } else {
                // Check for tier limit error
                if (response.data && response.data.tier && response.data.prompts_used >= response.data.prompts_limit) {
                    showUpgradePrompt(response.data);
                } else {
                    // Remove processing message and show error
                    chatBox.find('.nafcorp-message.system').last().remove();
                    addMessage(response.data.error || 'Could not understand the audio. Please try again.', 'system');
                }
            }
        })
        .fail(function() {
            setLoadingState(false);
            chatBox.find('.nafcorp-message.system').last().remove();
            addMessage('Failed to process audio. Please try again.', 'system');
        });
    }
    
    // ============================================
    // EVENT HANDLERS
    // ============================================
    
    // Send button
    sendButton.on('click', function() {
        const text = inputBox.val().trim();
        if (text) {
            sendMessage(text);
        }
    });
    
    // Mic button
    micButton.on('click', async function() {
        // Always use Realtime API for voice interaction
        if (isRealtimeActive) {
            stopRealtimeSession();
        } else {
            await startRealtimeSession();
        }
    });
    
    // Enter key to send
    inputBox.on('keypress', function(e) {
        if (e.which === 13 && !e.shiftKey) {
            e.preventDefault();
            sendButton.click();
        }
    });
    
    // Theme toggle
    themeButton.on('click', function() {
        isDarkMode = !isDarkMode;
        chatWidget.toggleClass('light-mode', !isDarkMode);
    });
    
    // Reset chat
    resetButton.on('click', function() {
        // Stop any playing audio
        if (currentAudio) {
            currentAudio.pause();
            currentAudio = null;
        }
        
        $.post(legacyConfig.ajax_url || ajaxUrl, {
            action: 'nafcorp_ai_reset_chat',
            nonce: legacyNonce || chatNonce
        })
        .done(function(response) {
            if (response.success) {
                chatBox.find('.nafcorp-message').remove();
                chatBox.find('.nafcorp-typing').remove();
                chatBox.find('.nafcorp-starters').remove();
                chatBox.find('.upgrade-prompt').remove();
                
                // Reset limit state if reset is allowed
                if (!isLimitReached) {
                    addMessage("Conversation reset. How can I help you?", "bot");
                    // Re-render conversation starters
                    setTimeout(renderConversationStarters, 300);
                } else {
                    addMessage("Conversation cleared. Please upgrade to continue chatting.", "system");
                }
            }
        });
    });
    
    // Export chat
    exportButton.on('click', function() {
        $.post(legacyConfig.ajax_url || ajaxUrl, {
            action: 'nafcorp_ai_export_chat',
            nonce: legacyNonce || chatNonce
        })
        .done(function(response) {
            if (response.success) {
                const exportData = {
                    exported_at: new Date().toISOString(),
                    conversation: response.data.conversation
                };
                
                const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `chat-export-${Date.now()}.json`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                
                addMessage("Chat exported successfully!", "system");
            }
        });
    });
    
    // ============================================
    // BROWSER SUPPORT CHECK
    // ============================================
    
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        micButton.prop('disabled', true)
            .attr('title', 'Voice input not supported in this browser')
            .css('opacity', '0.3');
    }
    
    // ============================================
    // RESPONSIVE HANDLING
    // ============================================
    
    function handleResize() {
        const isMobile = $(window).width() < 480;
        chatWidget.toggleClass('nafcorp-mobile', isMobile);
    }
    
    $(window).on('resize', handleResize);
    handleResize();
    
    // ============================================
    // INITIALIZATION COMPLETE
    // ============================================
    
    console.log('WPAssistant NT v2.3 initialized with TTS support');
});