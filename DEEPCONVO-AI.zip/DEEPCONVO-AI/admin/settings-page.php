<?php
/**
 * WPAssistant NT Settings Page - Advanced
 * With NAFCORP API Key Tier System + Tabbed Interface
 */

// Prevent direct access
if (!defined('ABSPATH')) exit;

// Determine active tab EARLY (needed for Save Logic)
$active_tab = isset($_GET['tab']) ? sanitize_text_field(wp_unslash($_GET['tab'])) : 'general';

// Handle File Uploads and Settings Save
if (isset($_POST['nafcorp_save_settings'])) {
    check_admin_referer('nafcorp_save_nonce', 'nafcorp_nonce');

    // Get the tab that triggered the save from the hidden input
    $saving_tab = isset($_POST['nafcorp_active_tab_save']) ? sanitize_text_field(wp_unslash($_POST['nafcorp_active_tab_save'])) : 'general';

    // Get existing settings to preserve data from other tabs
    $settings = get_option('nafcorp_ai_intake_settings', []);
    $upload_error_msg = ''; // Store upload errors
    
    // ==================================================
    // 1. GENERAL TAB SAVING
    // ==================================================
    if ($saving_tab === 'general') {
        if (isset($_POST['nafcorp_api_key'])) {
            $old_key = $settings['nafcorp_api_key'] ?? '';
            $new_key = sanitize_text_field(wp_unslash($_POST['nafcorp_api_key']));
            $settings['nafcorp_api_key'] = $new_key;
            
            // Check if NAFCORP key changed to reset registration flag
            if ($old_key !== $new_key) {
                $settings['nafcorp_key_registered'] = false;
            }
        }
        if (isset($_POST['openai_api_key'])) {
            $settings['api_key'] = sanitize_text_field(wp_unslash($_POST['openai_api_key']));
        }
        if (isset($_POST['model'])) {
            $settings['model'] = sanitize_text_field(wp_unslash($_POST['model']));
        }
    }
    
    // ==================================================
    // 2. PERSONA TAB SAVING
    // ==================================================
    if ($saving_tab === 'persona') {
        if (isset($_POST['bot_name'])) {
            $settings['bot_name'] = sanitize_text_field(wp_unslash($_POST['bot_name']));
        }
        if (isset($_POST['system_prompt'])) {
            $settings['system_prompt'] = sanitize_textarea_field(wp_unslash($_POST['system_prompt']));
        }
        if (isset($_POST['opening_message'])) {
            $settings['opening_message'] = sanitize_textarea_field(wp_unslash($_POST['opening_message']));
        }
        
        // Parse conversation starters
        if (isset($_POST['conversation_starters'])) {
            $starters_raw = sanitize_textarea_field(wp_unslash($_POST['conversation_starters']));
            $settings['starters'] = array_filter(array_map('trim', explode("\n", $starters_raw)));
        }
        
        if (isset($_POST['temperature'])) {
            $settings['temperature'] = floatval(wp_unslash($_POST['temperature']));
        }
        
        // Voice Settings (TTS)
        if (isset($_POST['nafcorp_ai_intake_voice'])) {
            $settings['voice'] = sanitize_text_field(wp_unslash($_POST['nafcorp_ai_intake_voice']));
        }
        
        // Checkbox Logic: If in persona tab, strictly check for presence
        $settings['enable_tts'] = isset($_POST['nafcorp_ai_intake_enable_tts']);
    }

    // ==================================================
    // 3. KNOWLEDGE TAB SAVING (RAG)
    // ==================================================
    if ($saving_tab === 'knowledge') {
        // Handle File Upload with Error Reporting
        if (!empty($_FILES['knowledge_file']['name'])) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            $file = $_FILES['knowledge_file'];
            $upload_overrides = ['test_form' => false];
            
            // Add filter temporarily to ensure JSON is allowed during this specific upload
            add_filter('upload_mimes', function($mimes) {
                $mimes['json'] = 'application/json';
                return $mimes;
            });

            $upload = wp_handle_upload($file, $upload_overrides);
            
            if (isset($upload['file']) && !isset($upload['error'])) {
                // Success
                if (!empty($settings['knowledge_file_path']) && file_exists($settings['knowledge_file_path'])) {
                    wp_delete_file($settings['knowledge_file_path']);
                }
                
                $settings['knowledge_file_path'] = $upload['file'];
                $settings['knowledge_file_url'] = $upload['url'];
                $settings['needs_openai_sync'] = true;
                
                // Clear old vector store IDs to force recreation
                $settings['vector_store_id'] = null;
                $settings['openai_file_id'] = null;
            } else {
                // Capture Error
                $upload_error_msg = isset($upload['error']) ? $upload['error'] : 'Unknown upload error';
            }
        }
        
        // Checkbox Logic
        $settings['enable_file_search'] = isset($_POST['enable_file_search']);
        $settings['enable_code_interpreter'] = isset($_POST['enable_code_interpreter']);
        $settings['code_interpreter'] = isset($_POST['enable_code_interpreter']);
    }

    // ==================================================
    // 4. INTERFACE TAB SAVING
    // ==================================================
    if ($saving_tab === 'interface') {
        if (isset($_POST['primary_color'])) {
            $settings['primary_color'] = sanitize_hex_color(wp_unslash($_POST['primary_color']));
        }
        if (isset($_POST['position'])) {
            $settings['position'] = sanitize_text_field(wp_unslash($_POST['position']));
        }
        
        if (isset($_POST['nafcorp_ai_intake_max_tokens'])) {
            $settings['max_tokens'] = intval(wp_unslash($_POST['nafcorp_ai_intake_max_tokens']));
        }
        
        // Checkbox Logic for Realtime
        $settings['use_realtime'] = isset($_POST['nafcorp_ai_intake_use_realtime']);
    }

    update_option('nafcorp_ai_intake_settings', $settings);
    
    // Trigger file upload if knowledge file was updated
    if (function_exists('nafcorp_sync_assistant') && !empty($settings['needs_openai_sync'])) {
        nafcorp_sync_assistant();
    }

    // DISPLAY NOTICES
    if (!empty($upload_error_msg)) {
        echo '<div class="notice notice-error"><p><strong>Upload Failed:</strong> ' . esc_html($upload_error_msg) . '</p></div>';
        if (strpos($upload_error_msg, 'type') !== false) {
            echo '<div class="notice notice-warning"><p>Tip: If you saw a security error, the JSON MIME type filter should now be enabled. Try uploading again.</p></div>';
        }
    } else {
        echo '<div class="notice notice-success"><p>Settings Saved Successfully!</p></div>';
    }
}

// Generate NAFCORP API Key on first install if not exists
$settings = get_option('nafcorp_ai_intake_settings', []);
if (empty($settings['nafcorp_api_key'])) {
    if (function_exists('nafcorp_generate_api_key')) {
        $settings['nafcorp_api_key'] = nafcorp_generate_api_key();
        update_option('nafcorp_ai_intake_settings', $settings);
    }
}

// Get tier status (Real-time check)
$nafcorp_tier_status = ['valid' => false, 'tier' => 'free', 'prompts_used' => 0, 'prompts_limit' => 5];
if (!empty($settings['nafcorp_api_key']) && function_exists('nafcorp_verify_api_key')) {
    $nafcorp_tier_status = nafcorp_verify_api_key($settings['nafcorp_api_key']);
}

// Calculate width for progress bar safely
$nafcorp_used = $nafcorp_tier_status['prompts_used'] ?? 0;
$nafcorp_limit = $nafcorp_tier_status['prompts_limit'] ?? 5;
$nafcorp_percent = ($nafcorp_limit > 0) ? min(100, ($nafcorp_used / $nafcorp_limit) * 100) : 0;
?>

<div class="wrap nafcorp-settings-wrap">
    <h1>🚀 DeepConvo AI - Advanced Builder</h1>
    
    <div class="notice notice-info">
        <p><strong>Welcome to DeepConvo AI!</strong> Build your custom AI assistant with RAG, File Search, Text-to-Speech, and advanced personalization.</p>
    </div>

    <!-- Tab Navigation -->
    <h2 class="nav-tab-wrapper">
        <a href="?page=nafcorp-ai-intake-settings&tab=general" class="nav-tab <?php echo $active_tab === 'general' ? 'nav-tab-active' : ''; ?>">🔑 General & Keys</a>
        <a href="?page=nafcorp-ai-intake-settings&tab=persona" class="nav-tab <?php echo $active_tab === 'persona' ? 'nav-tab-active' : ''; ?>">🤖 Identity & Voice</a>
        <a href="?page=nafcorp-ai-intake-settings&tab=knowledge" class="nav-tab <?php echo $active_tab === 'knowledge' ? 'nav-tab-active' : ''; ?>">📚 Knowledge Base (RAG)</a>
        <a href="?page=nafcorp-ai-intake-settings&tab=interface" class="nav-tab <?php echo $active_tab === 'interface' ? 'nav-tab-active' : ''; ?>">🎨 Interface Design</a>
    </h2>
    
    <form method="POST" enctype="multipart/form-data">
        <?php wp_nonce_field('nafcorp_save_nonce', 'nafcorp_nonce'); ?>
        <input type="hidden" name="nafcorp_save_settings" value="1">
        <input type="hidden" name="nafcorp_active_tab_save" value="<?php echo esc_attr($active_tab); ?>">

        <?php if ($active_tab === 'general'): ?>
        <!-- GENERAL TAB -->
        <h2 class="nafcorp-section-title">
            <span class="dashicons dashicons-admin-network"></span>
            NAFCORP License & API Keys
        </h2>
        
        <div class="nafcorp-tier-card <?php echo ($nafcorp_tier_status['tier'] ?? 'free') === 'paid' ? 'tier-paid' : 'tier-free'; ?>">
            <div class="tier-header">
                <div class="tier-badge">
                    <?php if (($nafcorp_tier_status['tier'] ?? 'free') === 'paid'): ?>
                        <span class="dashicons dashicons-yes-alt"></span>
                        <span>PAID TIER ACTIVE</span>
                    <?php else: ?>
                        <span class="dashicons dashicons-info"></span>
                        <span>FREE TIER</span>
                    <?php endif; ?>
                </div>
                <div class="tier-usage">
                    <?php if (($nafcorp_tier_status['tier'] ?? 'free') === 'paid'): ?>
                        <span class="usage-unlimited">♾️ Unlimited Prompts</span>
                    <?php else: ?>
                        <span class="usage-count"><?php echo esc_html($nafcorp_used); ?> / <?php echo esc_html($nafcorp_limit); ?> prompts used</span>
                        <div class="usage-bar"><div class="usage-fill" style="width: <?php echo esc_attr($nafcorp_percent); ?>%"></div></div>
                    <?php endif; ?>
                </div>
            </div>
            <?php if (($nafcorp_tier_status['tier'] ?? 'free') !== 'paid'): ?>
            <div class="tier-upgrade">
                <p>Upgrade to <strong>Paid Tier</strong> for unlimited prompts.</p>
                <a href="https://www.nafcorp.com.au/wpassistant-pricing" target="_blank" class="button button-primary">Upgrade Now</a>
            </div>
            <?php endif; ?>
        </div>
        
        <table class="form-table">
            <tr>
                <th scope="row"><label for="nafcorp_api_key_field">NAFCORP License Key</label></th>
                <td>
                    <div class="nafcorp-key-wrapper">
                        <input type="text" id="nafcorp_api_key_field" name="nafcorp_api_key" value="<?php echo esc_attr($settings['nafcorp_api_key'] ?? ''); ?>" class="regular-text nafcorp-key-input">
                        <button type="button" class="button" onclick="copyNafcorpKey()"><span class="dashicons dashicons-admin-page"></span> Copy</button>
                        <button type="button" class="button button-secondary" id="nafcorp-register-btn" onclick="registerNafcorpKey()"><span class="dashicons dashicons-upload"></span> Register</button>
                        <button type="button" class="button" onclick="refreshTierStatus()"><span class="dashicons dashicons-update"></span> Refresh</button>
                    </div>
                    <?php if (!empty($settings['nafcorp_key_registered'])): ?>
                        <p class="nafcorp-registered-badge"><span class="dashicons dashicons-yes-alt"></span> Registered & Active</p>
                    <?php else: ?>
                        <p class="nafcorp-error"><span class="dashicons dashicons-warning"></span> Not registered yet. Click "Register" above.</p>
                    <?php endif; ?>
                    <div id="nafcorp-register-result"></div>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="openai_api_key">OpenAI API Key</label></th>
                <td>
                    <input type="password" id="openai_api_key" name="openai_api_key" value="<?php echo esc_attr($settings['api_key'] ?? ''); ?>" class="regular-text">
                    <p class="description">Required for AI, TTS, and RAG. Get from <a href="https://platform.openai.com/api-keys" target="_blank">OpenAI Platform</a>.</p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="model">AI Model</label></th>
                <td>
                    <select name="model" id="model">
                        <option value="gpt-4o" <?php selected($settings['model'] ?? '', 'gpt-4o'); ?>>GPT-4o (Smartest)</option>
                        <option value="gpt-4o-mini" <?php selected($settings['model'] ?? '', 'gpt-4o-mini'); ?>>GPT-4o Mini (Fast)</option>
                        <option value="gpt-4-turbo" <?php selected($settings['model'] ?? '', 'gpt-4-turbo'); ?>>GPT-4 Turbo</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th scope="row"><label>Active Assistant ID</label></th>
                <td><input type="text" value="<?php echo esc_attr($settings['openai_assistant_id'] ?? 'Not created yet'); ?>" class="regular-text" readonly style="background:#f0f0f1;"></td>
            </tr>
        </table>
        <?php endif; ?>

        <?php if ($active_tab === 'persona'): ?>
        <!-- PERSONA TAB -->
        <h2>🤖 Bot Identity & Behavior</h2>
        <table class="form-table">
            <tr>
                <th scope="row"><label for="bot_name">Bot Name</label></th>
                <td><input type="text" id="bot_name" name="bot_name" value="<?php echo esc_attr($settings['bot_name'] ?? 'AI Assistant'); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th scope="row"><label for="system_prompt">System Instructions</label></th>
                <td><textarea id="system_prompt" name="system_prompt" rows="8" class="large-text code"><?php echo esc_textarea($settings['system_prompt'] ?? 'You are a helpful assistant.'); ?></textarea></td>
            </tr>
            <tr>
                <th scope="row"><label for="opening_message">Opening Message</label></th>
                <td><textarea id="opening_message" name="opening_message" rows="2" class="large-text"><?php echo esc_textarea($settings['opening_message'] ?? 'Hello! How can I help you today?'); ?></textarea></td>
            </tr>
            <tr>
                <th scope="row"><label for="conversation_starters">Conversation Starters</label></th>
                <td>
                    <textarea id="conversation_starters" name="conversation_starters" rows="4" class="large-text"><?php 
                        $starters = $settings['starters'] ?? [];
                        echo esc_textarea(is_array($starters) ? implode("\n", $starters) : ''); 
                    ?></textarea>
                    <p class="description">One per line. Example: "What services do you offer?"</p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="temperature">Creativity</label></th>
                <td>
                    <input type="range" id="temperature" name="temperature" min="0" max="1" step="0.1" value="<?php echo esc_attr($settings['temperature'] ?? 0.7); ?>" oninput="document.getElementById('temp-val').textContent = this.value">
                    <span class="range-val" id="temp-val"><?php echo esc_html($settings['temperature'] ?? 0.7); ?></span>
                </td>
            </tr>
        </table>
        
        <hr class="nafcorp-divider" />
        <h2 class="nafcorp-section-title"><span class="dashicons dashicons-format-audio"></span> Voice Settings (Text-to-Speech)</h2>
        <div class="notice notice-info inline"><p><strong>TTS:</strong> When enabled, the AI speaks responses aloud using OpenAI's TTS API.</p></div>
        <table class="form-table">
            <tr>
                <th scope="row">Enable TTS</th>
                <td>
                    <label class="nafcorp-toggle">
                        <input type="checkbox" name="nafcorp_ai_intake_enable_tts" <?php checked($settings['enable_tts'] ?? true); ?> />
                        <span class="toggle-slider"></span>
                        <span class="toggle-label">Enable voice responses</span>
                    </label>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="voice_selection">Voice</label></th>
                <td>
                    <select name="nafcorp_ai_intake_voice" id="voice_selection">
                        <option value="alloy" <?php selected($settings['voice'] ?? 'alloy', 'alloy'); ?>>🎙️ Alloy (Neutral)</option>
                        <option value="echo" <?php selected($settings['voice'] ?? 'alloy', 'echo'); ?>>🎙️ Echo (Male)</option>
                        <option value="fable" <?php selected($settings['voice'] ?? 'alloy', 'fable'); ?>>🎙️ Fable (British)</option>
                        <option value="onyx" <?php selected($settings['voice'] ?? 'alloy', 'onyx'); ?>>🎙️ Onyx (Deep)</option>
                        <option value="nova" <?php selected($settings['voice'] ?? 'alloy', 'nova'); ?>>🎙️ Nova (Female)</option>
                        <option value="shimmer" <?php selected($settings['voice'] ?? 'alloy', 'shimmer'); ?>>🎙️ Shimmer (Soft)</option>
                    </select>
                </td>
            </tr>
        </table>
        <?php endif; ?>

        <?php if ($active_tab === 'knowledge'): ?>
        <!-- KNOWLEDGE TAB -->
        <h2>📚 Knowledge Base & RAG</h2>
        <div class="notice notice-info inline"><p><strong>File Search (RAG):</strong> Upload documents to give your AI knowledge about your business.</p></div>
        <table class="form-table">
            <tr>
                <th scope="row"><label for="knowledge_file">Upload Knowledge File</label></th>
                <td>
                    <?php if (!empty($settings['knowledge_file_path'])): ?>
                        <div style="margin-bottom:15px; padding:12px; background:#f0f0f1; border-left:4px solid #1DFF85;">
                            <strong>Current:</strong> <code><?php echo esc_html(basename($settings['knowledge_file_path'])); ?></code>
                            <button type="button" class="button button-small" onclick="deleteKnowledgeFile()" style="margin-left:8px; color:#b32d2e;">Delete</button>
                            <?php if (!empty($settings['vector_store_id'])): ?>
                                <br><small>✅ Synced to OpenAI</small>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <input type="file" id="knowledge_file" name="knowledge_file" accept=".pdf,.txt,.docx,.doc,.md,.json">
                </td>
            </tr>
            <tr>
                <th scope="row">AI Capabilities</th>
                <td>
                    <label><input type="checkbox" name="enable_file_search" <?php checked($settings['enable_file_search'] ?? true); ?>> <strong>File Search (RAG)</strong></label><br>
                    <label><input type="checkbox" name="enable_code_interpreter" <?php checked($settings['enable_code_interpreter'] ?? false); ?>> <strong>Code Interpreter</strong></label>
                </td>
            </tr>
        </table>
        <?php endif; ?>

        <?php if ($active_tab === 'interface'): ?>
        <!-- INTERFACE TAB -->
        <h2>🎨 Interface Design</h2>
        <table class="form-table">
            <tr>
                <th scope="row"><label for="primary_color">Brand Color</label></th>
                <td><input type="color" id="primary_color" name="primary_color" value="<?php echo esc_attr($settings['primary_color'] ?? '#1DFF85'); ?>"></td>
            </tr>
            <tr>
                <th scope="row"><label for="position">Widget Position</label></th>
                <td>
                    <select name="position" id="position">
                        <option value="right" <?php selected($settings['position'] ?? 'right', 'right'); ?>>Bottom Right</option>
                        <option value="left" <?php selected($settings['position'] ?? 'left', 'left'); ?>>Bottom Left</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th scope="row">Max Tokens</th>
                <td><input type="number" name="nafcorp_ai_intake_max_tokens" value="<?php echo esc_attr($settings['max_tokens'] ?? 500); ?>" min="50" max="4000" class="small-text"></td>
            </tr>
            <tr>
                <th scope="row">Realtime API</th>
                <td><label><input type="checkbox" name="nafcorp_ai_intake_use_realtime" <?php checked($settings['use_realtime'] ?? false); ?> /> Enable (experimental)</label></td>
            </tr>
        </table>
        <?php endif; ?>

        <p class="submit"><input type="submit" class="button button-primary button-large" value="💾 Save All Changes"></p>
    </form>
</div>

<style>
.nafcorp-settings-wrap { max-width: 900px; }
.nafcorp-section-title { display: flex; align-items: center; gap: 8px; border-bottom: 2px solid #1DFF85; padding-bottom: 10px; margin-top: 30px; }
.nafcorp-tier-card { background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%); border-radius: 12px; padding: 24px; margin: 20px 0; color: #fff; border: 1px solid rgba(29, 255, 133, 0.3); }
.nafcorp-tier-card.tier-paid { border-color: #1DFF85; box-shadow: 0 0 20px rgba(29, 255, 133, 0.2); }
.tier-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; }
.tier-badge { display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 600; text-transform: uppercase; }
.tier-free .tier-badge { color: #ffc107; }
.tier-paid .tier-badge { color: #1DFF85; }
.usage-unlimited { font-size: 16px; color: #1DFF85; font-weight: 500; }
.usage-count { font-size: 14px; color: rgba(255, 255, 255, 0.7); display: block; margin-bottom: 8px; }
.usage-bar { width: 200px; height: 8px; background: rgba(255, 255, 255, 0.1); border-radius: 4px; overflow: hidden; }
.usage-fill { height: 100%; background: linear-gradient(90deg, #1DFF85, #00c853); }
.tier-upgrade { margin-top: 20px; padding-top: 20px; border-top: 1px solid rgba(255, 255, 255, 0.1); display: flex; justify-content: space-between; align-items: center; }
.tier-upgrade .button-primary { background: #1DFF85; border-color: #1DFF85; color: #000; font-weight: 600; }
.nafcorp-key-wrapper { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.nafcorp-key-input { font-family: monospace; }
.nafcorp-error { color: #d63638; margin-top: 8px; display: flex; align-items: center; gap: 4px; }
.nafcorp-registered-badge { color: #00a32a; font-weight: 600; display: flex; align-items: center; gap: 4px; }
.nafcorp-divider { margin: 30px 0; border-top: 1px solid #ddd; }
.nav-tab-wrapper { margin-bottom: 20px; }
.nav-tab-active { background: #f0f0f1; border-bottom: 1px solid #f0f0f1; }
input[type="range"] { width: 200px; vertical-align: middle; }
.range-val { font-weight: bold; margin-left: 10px; color: #1DFF85; }
.nafcorp-toggle { display: flex; align-items: center; gap: 12px; cursor: pointer; }
.nafcorp-toggle input[type="checkbox"] { display: none; }
.toggle-slider { width: 50px; height: 26px; background: #ccc; border-radius: 13px; position: relative; transition: background 0.3s; }
.toggle-slider::after { content: ''; position: absolute; width: 22px; height: 22px; background: white; border-radius: 50%; top: 2px; left: 2px; transition: transform 0.3s; box-shadow: 0 2px 4px rgba(0,0,0,0.2); }
.nafcorp-toggle input:checked + .toggle-slider { background: #1DFF85; }
.nafcorp-toggle input:checked + .toggle-slider::after { transform: translateX(24px); }
.toggle-label { font-weight: 500; }
.spin { animation: spin 1s linear infinite; }
@keyframes spin { 100% { transform: rotate(360deg); } }
</style>

<script>
function copyNafcorpKey() {
    const keyField = document.getElementById('nafcorp_api_key_field');
    keyField.select();
    navigator.clipboard.writeText(keyField.value);
    alert('Copied!');
}
function refreshTierStatus() { location.reload(); }

function deleteKnowledgeFile() {
    if (!confirm('Delete the knowledge file?')) return;
    jQuery.post(ajaxurl, {
        action: 'nafcorp_delete_knowledge_file',
        nonce: '<?php echo esc_js(wp_create_nonce("nafcorp_delete_file")); ?>'
    }, function(response) {
        if (response.success) location.reload();
        else alert('Error: ' + (response.data.error || 'Failed'));
    });
}

function registerNafcorpKey() {
    const keyField = document.getElementById('nafcorp_api_key_field');
    const apiKey = keyField.value.trim();
    const resultDiv = document.getElementById('nafcorp-register-result');
    const registerBtn = document.getElementById('nafcorp-register-btn');
    
    if (!apiKey) {
        resultDiv.innerHTML = '<div class="notice notice-error"><p>Enter an API key first.</p></div>';
        return;
    }
    
    registerBtn.disabled = true;
    registerBtn.innerHTML = '<span class="dashicons dashicons-update spin"></span> Registering...';
    
    jQuery.post(ajaxurl, {
        action: 'nafcorp_register_api_key',
        api_key: apiKey,
        nonce: '<?php echo esc_js(wp_create_nonce("nafcorp_register_key")); ?>'
    }, function(response) {
        registerBtn.disabled = false;
        if (response.success) {
            registerBtn.innerHTML = '<span class="dashicons dashicons-upload"></span> Re-Register';
            resultDiv.innerHTML = '<div class="notice notice-success"><p>Success! Registered.</p></div>';
            setTimeout(function() { location.reload(); }, 2000);
        } else {
            registerBtn.innerHTML = '<span class="dashicons dashicons-upload"></span> Register';
            resultDiv.innerHTML = '<div class="notice notice-error"><p>' + (response.data.error || 'Failed') + '</p></div>';
        }
    }).fail(function() {
        registerBtn.disabled = false;
        registerBtn.innerHTML = '<span class="dashicons dashicons-upload"></span> Register';
        resultDiv.innerHTML = '<div class="notice notice-error"><p>Connection error.</p></div>';
    });
}
</script>