<?php
/**
 * NAFCORP API Key Handler
 * * Handles API key verification, registration, and prompt limiting
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class NAFCORP_API_Handler {
    
    // TODO: REPLACE THIS WITH YOUR ACTUAL CLOUDFLARE WORKER URL
    private $worker_url = 'https://chatbot.holy-frog-0e8a.workers.dev'; 
    
    public function __construct() {
        add_action('wp_ajax_nafcorp_ai_chat', [$this, 'handle_chat'], 5); 
        add_action('wp_ajax_nopriv_nafcorp_ai_chat', [$this, 'handle_chat'], 5);
        
        // Add hooks for new Responses API handler
        add_action('wp_ajax_nafcorp_chat_message', [$this, 'handle_chat'], 5); 
        add_action('wp_ajax_nopriv_nafcorp_chat_message', [$this, 'handle_chat'], 5);
        
        // AJAX handler for manual registration from settings page
        add_action('wp_ajax_nafcorp_register_api_key', [$this, 'ajax_register_api_key']);
    }
    
    /**
     * AJAX handler for manual API key registration from settings page
     */
    public function ajax_register_api_key() {
        // Verify nonce
        // FIX: Verify nonce exists first to avoid notices
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'nafcorp_register_key')) {
            wp_send_json_error(['error' => 'Invalid security token.']);
            return;
        }
        
        // Check admin permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['error' => 'Unauthorized.']);
            return;
        }
        
        $api_key = isset($_POST['api_key']) ? sanitize_text_field(wp_unslash($_POST['api_key'])) : '';
        
        if (empty($api_key)) {
            wp_send_json_error(['error' => 'API key is required.']);
            return;
        }
        
        // Register with the worker
        $result = $this->register_api_key($api_key);
        
        if ($result) {
            // Save key and mark as registered
            $settings = get_option('nafcorp_ai_intake_settings', []);
            $settings['nafcorp_api_key'] = $api_key;
            $settings['nafcorp_key_registered'] = true;
            update_option('nafcorp_ai_intake_settings', $settings);
            
            // Get current status
            $status = $this->verify_api_key($api_key);
            
            wp_send_json_success([
                'message' => 'API key registered successfully!',
                'tier' => $status['tier'] ?? 'free',
                'prompts_limit' => $status['prompts_limit'] ?? 5,
                'prompts_used' => $status['prompts_used'] ?? 0
            ]);
        } else {
            wp_send_json_error(['error' => 'Failed to register with NAFCORP server. Please try again.']);
        }
    }

    /**
     * Check tier limits before processing chat
     */
    public function handle_chat() {
        // Verify nonce - check both new and legacy nonces
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        $nonce_verified = false;
        
        if (wp_verify_nonce($nonce, 'nafcorp_chat_nonce')) {
            $nonce_verified = true;
        } elseif (wp_verify_nonce($nonce, 'nafcorp_ai_nonce')) {
            $nonce_verified = true;
        }
        
        if (!$nonce_verified) {
            wp_send_json_error(['error' => 'Invalid security token.']);
            return;
        }
        
        $settings = get_option('nafcorp_ai_intake_settings', []);
        $nafcorp_key = $settings['nafcorp_api_key'] ?? '';
        $is_registered = $settings['nafcorp_key_registered'] ?? false;
        
        // Check if key exists
        if (empty($nafcorp_key)) {
            wp_send_json_error([
                'error' => 'No API key configured. Please go to WPAssistant settings and register your API key.',
                'not_registered' => true
            ]);
            exit;
        }
        
        // Check if key is registered with NAFCORP server
        if (!$is_registered) {
            wp_send_json_error([
                'error' => 'API key not registered. Please go to WPAssistant settings and click "Register" to activate your key.',
                'not_registered' => true
            ]);
            exit;
        }
        
        // Check and increment prompt count (this verifies key exists in D1 database)
        $result = $this->increment_prompt($nafcorp_key);
        
        if (!$result['allowed']) {
            wp_send_json_error([
                'error' => $result['error'] ?? 'Free tier limit reached. Please upgrade to continue.',
                'tier' => $result['tier'] ?? 'free',
                'prompts_used' => $result['prompts_used'] ?? 5,
                'prompts_limit' => $result['prompts_limit'] ?? 5,
                'upgrade_url' => 'https://www.nafcorp.com.au/wpassistant-pricing'
            ]);
            // Stop execution here so the main chat handler doesn't run
            exit; 
        }
        
        // If allowed, we do nothing and let the next hook (main chat handler) run
    }
    
    public function generate_api_key() {
        $prefix = 'nfc_';
        try {
            // FIX: Use wp_rand instead of rand
            $random_bytes = bin2hex(random_bytes(16));
        } catch (Exception $e) {
            $random_bytes = substr(md5(uniqid(wp_rand(), true)), 0, 32);
        }
        return $prefix . $random_bytes;
    }
    
    public function register_api_key($key = null) {
        if (!$key) return false;
        
        $site_url = get_site_url();
        
        $response = wp_remote_post($this->worker_url . '/register', [
            'body' => json_encode([
                'api_key' => $key,
                'site_url' => $site_url
            ]),
            'headers' => ['Content-Type' => 'application/json'],
            'timeout' => 15
        ]);
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body['success'] ?? false;
    }
    
    public function verify_api_key($api_key = null) {
        if (!$api_key) {
            $settings = get_option('nafcorp_ai_intake_settings', []);
            $api_key = $settings['nafcorp_api_key'] ?? '';
        }
        
        if (empty($api_key)) {
            return ['valid' => false, 'tier' => 'free', 'error' => 'No API key'];
        }
        
        $site_url = get_site_url();
        
        $response = wp_remote_post($this->worker_url . '/verify', [
            'body' => json_encode([
                'api_key' => $api_key,
                'site_url' => $site_url
            ]),
            'headers' => ['Content-Type' => 'application/json'],
            'timeout' => 15
        ]);
        
        if (is_wp_error($response)) {
            return ['valid' => false, 'error' => $response->get_error_message()];
        }
        
        return json_decode(wp_remote_retrieve_body($response), true);
    }
    
    public function increment_prompt($api_key) {
        $site_url = get_site_url();
        
        $response = wp_remote_post($this->worker_url . '/increment', [
            'body' => json_encode([
                'api_key' => $api_key,
                'site_url' => $site_url
            ]),
            'headers' => ['Content-Type' => 'application/json'],
            'timeout' => 15
        ]);
        
        if (is_wp_error($response)) {
            // Connection error - don't allow (fail closed for security)
            return [
                'success' => false,
                'allowed' => false,
                'error' => 'Unable to verify license. Please check your connection.'
            ];
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        // 404 = key not found in D1 database
        if ($code === 404) {
            // Mark as not registered locally
            $settings = get_option('nafcorp_ai_intake_settings', []);
            $settings['nafcorp_key_registered'] = false;
            update_option('nafcorp_ai_intake_settings', $settings);
            
            return [
                'success' => false,
                'allowed' => false,
                'error' => 'API key not found. Please register your key in the settings page.',
                'not_registered' => true
            ];
        }
        
        // 429 = rate limited (free tier exhausted)
        if ($code === 429) {
            return [
                'success' => false,
                'allowed' => false,
                'tier' => $body['tier'] ?? 'free',
                'prompts_used' => $body['prompts_used'] ?? 5,
                'prompts_limit' => $body['prompts_limit'] ?? 5,
                'error' => 'Free tier limit reached (5 prompts). Please upgrade to continue.'
            ];
        }
        
        // Success - check if allowed flag is present
        if (isset($body['allowed']) && $body['allowed'] === false) {
            return $body;
        }
        
        return $body ?? ['success' => true, 'allowed' => true];
    }
}

// Global instance
global $nafcorp_api_handler;
$nafcorp_api_handler = new NAFCORP_API_Handler();

// Helper functions for use in settings page
if (!function_exists('nafcorp_verify_api_key')) {
    function nafcorp_verify_api_key($api_key) {
        global $nafcorp_api_handler;
        return $nafcorp_api_handler->verify_api_key($api_key);
    }
}

if (!function_exists('nafcorp_generate_api_key')) {
    function nafcorp_generate_api_key() {
        global $nafcorp_api_handler;
        return $nafcorp_api_handler->generate_api_key();
    }
}